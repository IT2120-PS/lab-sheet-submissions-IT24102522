setwd("C:\\Users\\Sasuni\\Desktop\\Y2S1\\PS\\LabSheet\\PS_Lab09")

##01
set.seed(456)
baking <- rnorm(25, mean = 45, sd = 2)
baking

##02
t.test(baking, mu = 46, alternative = "less")
